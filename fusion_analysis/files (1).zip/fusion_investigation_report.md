# Fusion Phase 1 — Calibration, Complementarity & Error-Overlap Analysis

**Metabolic Disease Multimodal Platform — Fusion Investigation**
**Status: Evidence report only. No Fusion architecture is frozen. No Build Prompt follows this document.**

All statistics in this report are computed on the **Validation set (n=3,000)** unless explicitly marked "descriptive only / Test." Train was not used in this phase (no OOF work was performed here). Test was not used to make any architecture, weight, or threshold decision.

---

## Executive Conclusion

Multimodal Fusion is **not uniformly justified**. The evidence divides cleanly into two regimes:

- **Type2_Diabetes and Prediabetes**: Clinical is already at or near ceiling (Val ROC-AUC 0.9996 / 0.9993). A Validation-optimized weighted average assigns **100% of its weight to Clinical alone** for both labels — the optimizer itself rejects Fusion. No architecture beyond passthrough is justified here.
- **High_Adiposity_Risk**: A small, statistically distinguishable improvement exists (bootstrap 95% CI on ROC-AUC gain excludes zero, but the point estimate is only +0.0022). Real, but marginal.
- **Metabolic_Syndrome and NAFLD**: The strongest and clearest case for Fusion in the entire dataset. PR-AUC improves by 0.084 and 0.059 absolute respectively — large given these are the two rarest labels (7.7% and 14.2% prevalence). A confidence-band breakdown (Section 6) shows *why*: Clinical's own accuracy collapses to 21%–55% specifically in the mid-probability range (0.4–0.8) where it is most uncertain, and Gut's accuracy holds up far better in that same range. This is a genuine, mechanistically interpretable complementarity signal — not just a favorable point estimate.

A critical caveat applies to every positive finding above: **Strategy C's weights were tuned and evaluated on the same Validation set** (explicitly permitted for analysis-only purposes per the Phase 1 spec, not for deployment). The bootstrap CIs confirm the improvement is not resampling noise, but they do **not** correct for the optimism of fitting weights and reporting performance on the same 3,000 patients. Before any deployment decision, these effects must be re-confirmed via either (a) a proper OOF/nested-validation weight-selection procedure, or (b) the single untouched Test-set evaluation at the end of the full Fusion pipeline — not before.

A second, equally important finding: **across every disease and every pairwise combination, no modality "rescues" another above its own unconditional accuracy when analyzed as a simple wrong/right split** (Section 5). Every conditional rescue rate is flat or negative relative to baseline. This initially looks like evidence against complementarity everywhere — but Section 6's confidence-band analysis shows this conclusion is an artifact of pooling all confidence levels together. The real complementarity signal for Metabolic_Syndrome/NAFLD is concentrated specifically in Clinical's mid-confidence region, and is washed out when errors are analyzed in aggregate. This distinction is one of the most important findings in this report and should not be lost in downstream summarization.

**Wearable contributed zero incremental weight in the Validation-optimized blend for every single one of the five diseases.** Its glycemic signal (CGM) is highly redundant with Clinical's own glucose/HbA1c features (Pearson r = 0.92 for T2D, 0.84 for Prediabetes), and for the labels where Clinical's redundancy is lower, Wearable's standalone signal is too weak (NAFLD AUC 0.591) to earn weight over Gut. This is a strong, consistent finding, not noise — it recurred identically across all 5 independently-run grid searches.

---

## Section 1 — Artifact Verification

Verified directly from the exported artifacts (not assumed from prior documentation):

| Check | Result | Evidence |
|---|---|---|
| Patient population (20,000 IDs) identical across modalities | PASS | Split manifest + all 6 prediction files use identical Patient_ID sets |
| Split manifest (Train=14,000 / Val=3,000 / Test=3,000) | PASS | Verified counts match exactly |
| Val/Test Patient_ID sets match split manifest exactly | PASS | Set equality confirmed for all 3 modalities, both splits |
| Row order identical across modalities' Val files | PASS | Enables direct positional join used in `fusion_val_master.csv` |
| Ground truth in prediction files matches `labels_v3.csv` | PASS | Zero mismatches across all 5 labels × 3 modalities |
| Decision threshold = 0.5 | PASS (per artifact report) | Confirmed in inference scripts |
| 15/15 independently recomputed Test ROC-AUCs match reported values | PASS | Recomputed directly from raw probabilities in this session; exact match to 4 decimals |
| Modality-level missingness in current data | **Not represented** | All 20,000 patients have complete Clinical + Wearable + Gut data; only Gut's known feature-level MCAR (1,922 rows, already Train-median imputed) exists |

**One data characteristic surfaced during inspection, not previously documented**: several modality/disease probability columns show substantial value quantization — e.g., Clinical's Type2_Diabetes probability takes only 197 distinct values across 3,000 patients (two dominant clusters at 0.066 and 0.934), and Wearable's Metabolic_Syndrome probability takes only 495 distinct values. This is consistent with tree-ensemble outputs on a strongly separable problem (few distinct leaf-value combinations required), not a data pipeline defect — the independently-recomputed AUCs match exactly, confirming the predictions themselves are correct. It does mean equal-width probability bins would distort reliability diagrams for these columns; **equal-frequency bins were used throughout this report's calibration analysis** to avoid that distortion.

---

## Section 2 — Calibration Analysis

![Reliability diagrams by disease](plots/reliability_diagrams.png)

| Disease             | Modality   |   ROC_AUC |   PR_AUC |   Brier |   Mean_Predicted_P |   Prevalence |   Calib_Slope |   Calib_Intercept | Calibration_Class           |
|:--------------------|:-----------|----------:|---------:|--------:|-------------------:|-------------:|--------------:|------------------:|:----------------------------|
| Type2_Diabetes      | Clinical   |    0.9996 |   0.9994 |  0.0075 |             0.383  |       0.3643 |        2.6611 |            1.0404 | Substantially miscalibrated |
| Type2_Diabetes      | Wearable   |    0.9909 |   0.9848 |  0.04   |             0.3899 |       0.3643 |        1.141  |           -0.7265 | Mildly miscalibrated        |
| Type2_Diabetes      | Gut        |    0.8236 |   0.7277 |  0.1717 |             0.4527 |       0.3643 |        1.1491 |           -0.5203 | Mildly miscalibrated        |
| Prediabetes         | Clinical   |    0.9993 |   0.9985 |  0.0057 |             0.329  |       0.324  |        1.1617 |           -0.8484 | Substantially miscalibrated |
| Prediabetes         | Wearable   |    0.9648 |   0.9295 |  0.0726 |             0.361  |       0.324  |        1.0455 |           -0.5383 | Mildly miscalibrated        |
| Prediabetes         | Gut        |    0.617  |   0.4202 |  0.2377 |             0.4853 |       0.324  |        1.2799 |           -0.6921 | Mildly miscalibrated        |
| High_Adiposity_Risk | Clinical   |    0.9665 |   0.9327 |  0.0749 |             0.3696 |       0.3163 |        1.0678 |           -0.7842 | Mildly miscalibrated        |
| High_Adiposity_Risk | Wearable   |    0.7959 |   0.6178 |  0.1844 |             0.443  |       0.3163 |        0.9444 |           -0.7306 | Mildly miscalibrated        |
| High_Adiposity_Risk | Gut        |    0.8061 |   0.6738 |  0.1758 |             0.4351 |       0.3163 |        0.9937 |           -0.7003 | Mildly miscalibrated        |
| Metabolic_Syndrome  | Clinical   |    0.9089 |   0.4665 |  0.1257 |             0.2994 |       0.077  |        1.416  |           -2.4366 | Substantially miscalibrated |
| Metabolic_Syndrome  | Wearable   |    0.7387 |   0.1658 |  0.2276 |             0.4769 |       0.077  |        3.6579 |           -2.4197 | Substantially miscalibrated |
| Metabolic_Syndrome  | Gut        |    0.8359 |   0.369  |  0.1568 |             0.3461 |       0.077  |        1.2261 |           -2.3628 | Substantially miscalibrated |
| NAFLD               | Clinical   |    0.9109 |   0.6534 |  0.1226 |             0.2954 |       0.142  |        1.0005 |           -1.6662 | Substantially miscalibrated |
| NAFLD               | Wearable   |    0.5914 |   0.1912 |  0.2411 |             0.4887 |       0.142  |        1.2364 |           -1.7759 | Substantially miscalibrated |
| NAFLD               | Gut        |    0.815  |   0.4859 |  0.1699 |             0.3872 |       0.142  |        1.1506 |           -1.725  | Substantially miscalibrated |

**Calibration classification is driven primarily by disease prevalence, not by modality quality.** Every "Substantially miscalibrated" call belongs to either Clinical on a low-prevalence label (Metabolic_Syndrome 7.7%, NAFLD 14.2%) or a very high-AUC/near-separable case (T2D). The calibration intercepts scale with how rare the label is, which is the expected signature of `scale_pos_weight` class-rebalancing during training (used by all three modalities per the original build specification) — rebalancing deliberately shifts predicted probabilities away from raw prevalence to counter class imbalance during training, at the cost of the raw probability's literal interpretability as a calibrated risk. This is not a modeling flaw; it does mean **raw probability magnitude should not be read as calibrated risk across modalities without adjustment**, and any Fusion strategy that mixes probabilities (weighted averaging, LR stacking) is implicitly working with these prevalence-driven offsets already baked in.

Gut and Wearable are more consistently only "mildly miscalibrated" on higher-prevalence labels, but substantially miscalibrated on the same two rare labels as Clinical — again tracking prevalence rather than modality identity.

**Implication for Fusion**: Do not interpret "Clinical P=0.8" and "Gut P=0.8" as the same quantity without adjustment, particularly for Metabolic_Syndrome and NAFLD. The Validation-optimized weighted average (Section 7) implicitly absorbs some of this miscalibration into its fitted weights, which is a partial but not a clean solution — recalibration prior to fusion remains an open question for Phase 2, not resolved here per the spec's "diagnose, don't correct yet" instruction.

---

## Section 3 — Probability Correlation Analysis

![Correlation heatmaps by disease](plots/correlation_heatmaps.png)

**Pearson correlation:**

| Disease             |   Clinical-Wearable_Pearson |   Clinical-Gut_Pearson |   Wearable-Gut_Pearson |
|:--------------------|----------------------------:|-----------------------:|-----------------------:|
| Type2_Diabetes      |                       0.921 |                  0.541 |                  0.535 |
| Prediabetes         |                       0.837 |                  0.181 |                  0.18  |
| High_Adiposity_Risk |                       0.609 |                  0.501 |                  0.438 |
| Metabolic_Syndrome  |                       0.459 |                  0.485 |                  0.491 |
| NAFLD               |                       0.235 |                  0.366 |                  0.51  |

**Spearman correlation:**

| Disease             |   Clinical-Wearable_Spearman |   Clinical-Gut_Spearman |   Wearable-Gut_Spearman |
|:--------------------|-----------------------------:|------------------------:|------------------------:|
| Type2_Diabetes      |                        0.882 |                   0.541 |                   0.542 |
| Prediabetes         |                        0.837 |                   0.209 |                   0.198 |
| High_Adiposity_Risk |                        0.652 |                   0.494 |                   0.435 |
| Metabolic_Syndrome  |                        0.484 |                   0.469 |                   0.504 |
| NAFLD               |                        0.248 |                   0.337 |                   0.511 |

Interpretation, per disease:

- **T2D / Prediabetes**: Clinical-Wearable correlation is very high (0.92 / 0.84) — both carry strongly overlapping glycemic information (Clinical's HbA1c/fasting glucose vs. Wearable's CGM). Clinical-Gut and Wearable-Gut correlations are moderate (~0.18–0.54), meaning Gut is the more distinct signal, but Gut's own standalone AUC is too weak on these labels for that distinctness to translate into a rescue.
- **High_Adiposity_Risk**: Correlations are moderate across the board (0.44–0.61). Clinical-Wearable (0.61) is higher than Clinical-Gut (0.50), consistent with the weighted-average optimizer assigning all incremental weight to Gut, not Wearable.
- **Metabolic_Syndrome**: All three pairwise correlations are similar and moderate (~0.46–0.49) — a genuinely more balanced information landscape than the glycemic labels.
- **NAFLD**: Clinical-Wearable correlation is the **lowest of any label** (0.235) — but this reflects Wearable's near-noise standalone performance on NAFLD (AUC 0.591), not useful independence. Clinical-Gut (0.366) and especially Wearable-Gut (0.510) correlations are higher.

**Important nuance**: low correlation alone does not imply usefulness — Wearable-NAFLD's low correlation with Clinical exists precisely because Wearable is *not* tracking the same signal as Clinical *or* the disease itself very well. Distinctness is a necessary but not sufficient condition for complementarity; Section 6/7's error analysis is what determines whether the distinct signal is *useful*.

---

## Section 4 — Prediction Disagreement Analysis

Using fixed threshold = 0.5 on Validation:

| Disease | All 3 Agree | % |
|---|---:|---:|
| Type2_Diabetes | 2,125 | 70.8% |
| Prediabetes | 1,466 | 48.9% |
| High_Adiposity_Risk | 1,639 | 54.6% |
| Metabolic_Syndrome | 1,659 | 55.3% |
| NAFLD | 1,408 | 46.9% |

Full per-disease contingency tables (pattern = C/W/G, 1=positive prediction, 0=negative):

(see Section 4 summary table above and disagreement_tables.json for full per-disease breakdown)

Disagreement is substantial for every label — even T2D, where Clinical is near-perfect, still has 29.2% of patients where at least one modality disagrees with the others. This confirms there is *something* for a Fusion layer to potentially exploit on every label; whether that something is useful signal or correlated noise is answered in Sections 5–6.

---

## Section 5 — Error Overlap / Complementarity Analysis

**Base classification metrics (threshold = 0.5, Validation):**

| Disease             | Modality   |   Accuracy |   Recall |   Specificity |   Precision |    F1 |
|:--------------------|:-----------|-----------:|---------:|--------------:|------------:|------:|
| Type2_Diabetes      | Clinical   |      0.997 |    0.993 |         1     |       1     | 0.996 |
| Type2_Diabetes      | Wearable   |      0.943 |    0.959 |         0.933 |       0.892 | 0.924 |
| Type2_Diabetes      | Gut        |      0.746 |    0.715 |         0.764 |       0.634 | 0.672 |
| Prediabetes         | Clinical   |      0.994 |    0.996 |         0.994 |       0.987 | 0.991 |
| Prediabetes         | Wearable   |      0.898 |    0.898 |         0.898 |       0.808 | 0.851 |
| Prediabetes         | Gut        |      0.532 |    0.718 |         0.443 |       0.382 | 0.499 |
| High_Adiposity_Risk | Clinical   |      0.892 |    0.913 |         0.882 |       0.782 | 0.842 |
| High_Adiposity_Risk | Wearable   |      0.711 |    0.729 |         0.703 |       0.532 | 0.615 |
| High_Adiposity_Risk | Gut        |      0.707 |    0.75  |         0.687 |       0.526 | 0.618 |
| Metabolic_Syndrome  | Clinical   |      0.81  |    0.87  |         0.805 |       0.272 | 0.414 |
| Metabolic_Syndrome  | Wearable   |      0.657 |    0.675 |         0.655 |       0.14  | 0.232 |
| Metabolic_Syndrome  | Gut        |      0.706 |    0.766 |         0.701 |       0.176 | 0.287 |
| NAFLD               | Clinical   |      0.814 |    0.829 |         0.812 |       0.422 | 0.559 |
| NAFLD               | Wearable   |      0.566 |    0.573 |         0.564 |       0.179 | 0.272 |
| NAFLD               | Gut        |      0.703 |    0.758 |         0.693 |       0.29  | 0.42  |

**Pairwise error overlap, by disease:**

#### Type2_Diabetes

| Pair                 |   Both_Correct |   Both_Correct_pct |   Clinical_Correct_Wearable_Wrong |   pct1 |   Clinical_Wrong_Wearable_Correct |   pct2 |   Both_Wrong |   Both_Wrong_pct |   Clinical_Correct_Gut_Wrong |   Clinical_Wrong_Gut_Correct |   Wearable_Correct_Gut_Wrong |   Wearable_Wrong_Gut_Correct |
|:---------------------|---------------:|-------------------:|----------------------------------:|-------:|----------------------------------:|-------:|-------------:|-----------------:|-----------------------------:|-----------------------------:|-----------------------------:|-----------------------------:|
| Clinical vs Wearable |           2826 |               94.2 |                               166 |    5.5 |                                 2 |    0.1 |            6 |              0.2 |                          nan |                          nan |                          nan |                          nan |
| Clinical vs Gut      |           2231 |               74.4 |                               nan |   25.4 |                               nan |    0.2 |            2 |              0.1 |                          761 |                            6 |                          nan |                          nan |
| Wearable vs Gut      |           2125 |               70.8 |                               nan |   23.4 |                               nan |    3.7 |           60 |              2   |                          nan |                          nan |                          703 |                          112 |

#### Prediabetes

| Pair                 |   Both_Correct |   Both_Correct_pct |   Clinical_Correct_Wearable_Wrong |   pct1 |   Clinical_Wrong_Wearable_Correct |   pct2 |   Both_Wrong |   Both_Wrong_pct |   Clinical_Correct_Gut_Wrong |   Clinical_Wrong_Gut_Correct |   Wearable_Correct_Gut_Wrong |   Wearable_Wrong_Gut_Correct |
|:---------------------|---------------:|-------------------:|----------------------------------:|-------:|----------------------------------:|-------:|-------------:|-----------------:|-----------------------------:|-----------------------------:|-----------------------------:|-----------------------------:|
| Clinical vs Wearable |           2689 |               89.6 |                               294 |    9.8 |                                 5 |    0.2 |           12 |              0.4 |                          nan |                          nan |                          nan |                          nan |
| Clinical vs Gut      |           1587 |               52.9 |                               nan |   46.5 |                               nan |    0.3 |            7 |              0.2 |                         1396 |                           10 |                          nan |                          nan |
| Wearable vs Gut      |           1464 |               48.8 |                               nan |   41   |                               nan |    4.4 |          173 |              5.8 |                          nan |                          nan |                         1230 |                          133 |

#### High_Adiposity_Risk

| Pair                 |   Both_Correct |   Both_Correct_pct |   Clinical_Correct_Wearable_Wrong |   pct1 |   Clinical_Wrong_Wearable_Correct |   pct2 |   Both_Wrong |   Both_Wrong_pct |   Clinical_Correct_Gut_Wrong |   Clinical_Wrong_Gut_Correct |   Wearable_Correct_Gut_Wrong |   Wearable_Wrong_Gut_Correct |
|:---------------------|---------------:|-------------------:|----------------------------------:|-------:|----------------------------------:|-------:|-------------:|-----------------:|-----------------------------:|-----------------------------:|-----------------------------:|-----------------------------:|
| Clinical vs Wearable |           2033 |               67.8 |                               643 |   21.4 |                               101 |    3.4 |          223 |              7.4 |                          nan |                          nan |                          nan |                          nan |
| Clinical vs Gut      |           1932 |               64.4 |                               nan |   24.8 |                               nan |    6.3 |          135 |              4.5 |                          744 |                          189 |                          nan |                          nan |
| Wearable vs Gut      |           1605 |               53.5 |                               nan |   17.6 |                               nan |   17.2 |          350 |             11.7 |                          nan |                          nan |                          529 |                          516 |

#### Metabolic_Syndrome

| Pair                 |   Both_Correct |   Both_Correct_pct |   Clinical_Correct_Wearable_Wrong |   pct1 |   Clinical_Wrong_Wearable_Correct |   pct2 |   Both_Wrong |   Both_Wrong_pct |   Clinical_Correct_Gut_Wrong |   Clinical_Wrong_Gut_Correct |   Wearable_Correct_Gut_Wrong |   Wearable_Wrong_Gut_Correct |
|:---------------------|---------------:|-------------------:|----------------------------------:|-------:|----------------------------------:|-------:|-------------:|-----------------:|-----------------------------:|-----------------------------:|-----------------------------:|-----------------------------:|
| Clinical vs Wearable |           1758 |               58.6 |                               673 |   22.4 |                               212 |    7.1 |          357 |             11.9 |                          nan |                          nan |                          nan |                          nan |
| Clinical vs Gut      |           1841 |               61.4 |                               nan |   19.7 |                               nan |    9.3 |          291 |              9.7 |                          590 |                          278 |                          nan |                          nan |
| Wearable vs Gut      |           1580 |               52.7 |                               nan |   13   |                               nan |   18   |          491 |             16.4 |                          nan |                          nan |                          390 |                          539 |

#### NAFLD

| Pair                 |   Both_Correct |   Both_Correct_pct |   Clinical_Correct_Wearable_Wrong |   pct1 |   Clinical_Wrong_Wearable_Correct |   pct2 |   Both_Wrong |   Both_Wrong_pct |   Clinical_Correct_Gut_Wrong |   Clinical_Wrong_Gut_Correct |   Wearable_Correct_Gut_Wrong |   Wearable_Wrong_Gut_Correct |
|:---------------------|---------------:|-------------------:|----------------------------------:|-------:|----------------------------------:|-------:|-------------:|-----------------:|-----------------------------:|-----------------------------:|-----------------------------:|-----------------------------:|
| Clinical vs Wearable |           1462 |               48.7 |                               981 |   32.7 |                               235 |    7.8 |          322 |             10.7 |                          nan |                          nan |                          nan |                          nan |
| Clinical vs Gut      |           1785 |               59.5 |                               nan |   21.9 |                               nan |   10.8 |          234 |              7.8 |                          658 |                          323 |                          nan |                          nan |
| Wearable vs Gut      |           1409 |               47   |                               nan |    9.6 |                               nan |   23.3 |          604 |             20.1 |                          nan |                          nan |                          288 |                          699 |

**Conditional rescue rates vs. unconditional accuracy (the base-rate-corrected comparison the spec requires):**

| Disease             | When_Wrong   | Rescuer   |   N_Wrong_Cases |   P_Rescuer_Correct_Given_Wrong |   Rescuer_Unconditional_Accuracy |   Delta_vs_Unconditional |
|:--------------------|:-------------|:----------|----------------:|--------------------------------:|---------------------------------:|-------------------------:|
| Type2_Diabetes      | Clinical     | Wearable  |               8 |                           0.25  |                            0.943 |                   -0.693 |
| Type2_Diabetes      | Clinical     | Gut       |               8 |                           0.75  |                            0.746 |                    0.004 |
| Type2_Diabetes      | Wearable     | Clinical  |             172 |                           0.965 |                            0.997 |                   -0.032 |
| Type2_Diabetes      | Wearable     | Gut       |             172 |                           0.651 |                            0.746 |                   -0.095 |
| Type2_Diabetes      | Gut          | Clinical  |             763 |                           0.997 |                            0.997 |                    0     |
| Type2_Diabetes      | Gut          | Wearable  |             763 |                           0.921 |                            0.943 |                   -0.021 |
| Prediabetes         | Clinical     | Wearable  |              17 |                           0.294 |                            0.898 |                   -0.604 |
| Prediabetes         | Clinical     | Gut       |              17 |                           0.588 |                            0.532 |                    0.056 |
| Prediabetes         | Wearable     | Clinical  |             306 |                           0.961 |                            0.994 |                   -0.034 |
| Prediabetes         | Wearable     | Gut       |             306 |                           0.435 |                            0.532 |                   -0.098 |
| Prediabetes         | Gut          | Clinical  |            1403 |                           0.995 |                            0.994 |                    0.001 |
| Prediabetes         | Gut          | Wearable  |            1403 |                           0.877 |                            0.898 |                   -0.021 |
| High_Adiposity_Risk | Clinical     | Wearable  |             324 |                           0.312 |                            0.711 |                   -0.4   |
| High_Adiposity_Risk | Clinical     | Gut       |             324 |                           0.583 |                            0.707 |                   -0.124 |
| High_Adiposity_Risk | Wearable     | Clinical  |             866 |                           0.742 |                            0.892 |                   -0.15  |
| High_Adiposity_Risk | Wearable     | Gut       |             866 |                           0.596 |                            0.707 |                   -0.111 |
| High_Adiposity_Risk | Gut          | Clinical  |             879 |                           0.846 |                            0.892 |                   -0.046 |
| High_Adiposity_Risk | Gut          | Wearable  |             879 |                           0.602 |                            0.711 |                   -0.11  |
| Metabolic_Syndrome  | Clinical     | Wearable  |             569 |                           0.373 |                            0.657 |                   -0.284 |
| Metabolic_Syndrome  | Clinical     | Gut       |             569 |                           0.489 |                            0.706 |                   -0.218 |
| Metabolic_Syndrome  | Wearable     | Clinical  |            1030 |                           0.653 |                            0.81  |                   -0.157 |
| Metabolic_Syndrome  | Wearable     | Gut       |            1030 |                           0.523 |                            0.706 |                   -0.183 |
| Metabolic_Syndrome  | Gut          | Clinical  |             881 |                           0.67  |                            0.81  |                   -0.141 |
| Metabolic_Syndrome  | Gut          | Wearable  |             881 |                           0.443 |                            0.657 |                   -0.214 |
| NAFLD               | Clinical     | Wearable  |             557 |                           0.422 |                            0.566 |                   -0.144 |
| NAFLD               | Clinical     | Gut       |             557 |                           0.58  |                            0.703 |                   -0.123 |
| NAFLD               | Wearable     | Clinical  |            1303 |                           0.753 |                            0.814 |                   -0.061 |
| NAFLD               | Wearable     | Gut       |            1303 |                           0.536 |                            0.703 |                   -0.166 |
| NAFLD               | Gut          | Clinical  |             892 |                           0.738 |                            0.814 |                   -0.077 |
| NAFLD               | Gut          | Wearable  |             892 |                           0.323 |                            0.566 |                   -0.243 |

**This is the central and most sobering finding in the pairwise analysis: every single `Delta_vs_Unconditional` value in the table above is negative or effectively zero.** There is no pairing, on any disease, where a modality performs *better* specifically on the cases where another modality fails. At best (T2D, Gut correct | Clinical wrong = 0.750 vs. Gut's unconditional 0.746, delta +0.004; T2D, Clinical correct | Gut wrong = 0.997 vs unconditional 0.997, delta 0.000) the relationship is neutral — errors are independent, not complementary. At worst (NAFLD, Gut correct | Wearable wrong = 0.323 vs. Gut's unconditional 0.703, delta -0.243) a modality performs *dramatically worse* exactly where it would need to rescue.

Two caveats on interpreting this table:

1. **Sample size**: For T2D and Prediabetes, "Clinical wrong" occurs in only 8 and 17 Validation patients respectively. Any conditional rate computed on 8–17 cases is not statistically reliable and should not be used to argue for or against Fusion on these labels — the near-ceiling AUC itself is the stronger evidence there.
2. **This table pools all confidence levels together.** It answers "does Y do better than usual when X is simply wrong (binary)?" It does *not* answer "does Y do better than X specifically in the region where X is uncertain?" Those are different questions, and Section 6 shows they give different answers for Metabolic_Syndrome and NAFLD.

---

## Section 6 — Confidence-Band ("Can Others Rescue Clinical?") Analysis

This is the analysis that reconciles the flat/negative picture in Section 5 with the positive Fusion Potential findings in Section 8. Rather than asking "correct or wrong," this segments patients by **Clinical's own predicted probability**, since Clinical's reliability is not uniform across its own probability range.

| Disease             | Clinical_P_Band   |    N |   Clinical_Acc_InBand |   Wearable_Acc_InBand |   Gut_Acc_InBand |   Either_W_or_G_Correct_InBand |   Both_W_and_G_Correct_InBand |
|:--------------------|:------------------|-----:|----------------------:|----------------------:|-----------------:|-------------------------------:|------------------------------:|
| Type2_Diabetes      | <0.2              | 1903 |                 0.996 |                 0.932 |            0.764 |                          0.977 |                         0.719 |
| Type2_Diabetes      | 0.2-0.4           |   12 |                 1     |                 0.667 |            0.667 |                          1     |                         0.333 |
| Type2_Diabetes      | 0.4-0.6           |    2 |                 1     |                 0     |            0.5   |                          0.5   |                         0     |
| Type2_Diabetes      | 0.6-0.8           |    7 |                 1     |                 0.714 |            0.857 |                          0.857 |                         0.714 |
| Type2_Diabetes      | >0.8              | 1076 |                 1     |                 0.967 |            0.714 |                          0.987 |                         0.694 |
| Prediabetes         | <0.2              | 2005 |                 0.998 |                 0.905 |            0.443 |                          0.937 |                         0.411 |
| Prediabetes         | 0.2-0.4           |   10 |                 1     |                 0.4   |            0.6   |                          0.6   |                         0.4   |
| Prediabetes         | 0.4-0.6           |    7 |                 0.714 |                 0.286 |            0     |                          0.286 |                         0     |
| Prediabetes         | 0.6-0.8           |    8 |                 0.75  |                 0.375 |            0.125 |                          0.5   |                         0     |
| Prediabetes         | >0.8              |  970 |                 0.991 |                 0.897 |            0.723 |                          0.965 |                         0.655 |
| High_Adiposity_Risk | <0.2              | 1590 |                 0.989 |                 0.792 |            0.713 |                          0.917 |                         0.587 |
| High_Adiposity_Risk | 0.2-0.4           |  215 |                 0.833 |                 0.479 |            0.6   |                          0.753 |                         0.326 |
| High_Adiposity_Risk | 0.4-0.6           |  182 |                 0.511 |                 0.429 |            0.643 |                          0.769 |                         0.302 |
| High_Adiposity_Risk | 0.6-0.8           |  217 |                 0.544 |                 0.47  |            0.677 |                          0.793 |                         0.355 |
| High_Adiposity_Risk | >0.8              |  796 |                 0.897 |                 0.744 |            0.747 |                          0.902 |                         0.589 |
| Metabolic_Syndrome  | <0.2              | 1619 |                 0.996 |                 0.775 |            0.796 |                          0.916 |                         0.654 |
| Metabolic_Syndrome  | 0.2-0.4           |  458 |                 0.972 |                 0.603 |            0.677 |                          0.828 |                         0.452 |
| Metabolic_Syndrome  | 0.4-0.6           |  358 |                 0.547 |                 0.492 |            0.575 |                          0.715 |                         0.352 |
| Metabolic_Syndrome  | 0.6-0.8           |  380 |                 0.213 |                 0.437 |            0.513 |                          0.668 |                         0.282 |
| Metabolic_Syndrome  | >0.8              |  185 |                 0.524 |                 0.53  |            0.649 |                          0.741 |                         0.438 |
| NAFLD               | <0.2              | 1668 |                 0.991 |                 0.613 |            0.73  |                          0.836 |                         0.507 |
| NAFLD               | 0.2-0.4           |  362 |                 0.909 |                 0.489 |            0.68  |                          0.765 |                         0.403 |
| NAFLD               | 0.4-0.6           |  252 |                 0.504 |                 0.476 |            0.591 |                          0.659 |                         0.409 |
| NAFLD               | 0.6-0.8           |  330 |                 0.288 |                 0.512 |            0.655 |                          0.764 |                         0.403 |
| NAFLD               | >0.8              |  388 |                 0.616 |                 0.539 |            0.722 |                          0.791 |                         0.469 |

**The key result, isolated:**

| Disease | Clinical P Band | N | Clinical Acc | Wearable Acc | Gut Acc | Either W/G Correct |
|---|---|---:|---:|---:|---:|---:|
| Metabolic_Syndrome | 0.4–0.6 | 358 | **0.547** | 0.492 | 0.575 | 0.715 |
| Metabolic_Syndrome | 0.6–0.8 | 380 | **0.213** | 0.437 | 0.513 | 0.668 |
| NAFLD | 0.4–0.6 | 252 | **0.504** | 0.476 | 0.591 | 0.659 |
| NAFLD | 0.6–0.8 | 330 | **0.288** | 0.512 | 0.655 | 0.764 |

In the 0.6–0.8 Clinical-probability band — where Clinical is confidently leaning positive but is in fact wrong more often than not — **Gut's accuracy in that exact same slice of patients is more than double Clinical's** for both Metabolic_Syndrome (0.513 vs 0.213) and NAFLD (0.655 vs 0.288). This affects a non-trivial 380 and 330 Validation patients respectively (roughly 11–13% of Validation for this band alone; 19–25% of Validation across both mid-confidence bands combined).

This is the mechanistic explanation for why Metabolic_Syndrome and NAFLD show real Fusion improvement in Section 7 despite Section 5's flat aggregate rescue rates: **the rescue effect is real, but concentrated in a specific, identifiable region of Clinical's own probability space, not spread evenly across all of Clinical's errors.** A pairwise correct/wrong split averages this concentrated effect away.

For High_Adiposity_Risk, a smaller but directionally similar pattern exists in the 0.4–0.8 range (Clinical accuracy 0.51–0.54, Gut 0.60–0.68). For T2D and Prediabetes, the mid-confidence bands contain too few patients (2–12) to draw any conclusion; the >0.8 and <0.2 bands (where nearly all Validation patients sit) show Clinical already near-perfect, leaving no room for rescue.

---

## Section 7 — Fusion Candidate Comparison

**Strategy A (best single modality)** vs **Strategy C (Validation-optimized weighted average, coarse grid search, weights fit and evaluated on the same Validation set — analysis only, not deployment-ready)**:

| Disease             | Best_Modality (A)   |   ROC_AUC_A |   ROC_AUC_C |   ROC_AUC_diff |   PR_AUC_A |   PR_AUC_C |   PR_AUC_diff |   F1_A |   F1_C |   F1_diff |   Brier_A |   Brier_C |   Brier_diff | Bootstrap_95CI_AUC_diff   | CI_excludes_zero   |
|:--------------------|:--------------------|------------:|------------:|---------------:|-----------:|-----------:|--------------:|-------:|-------:|----------:|----------:|----------:|-------------:|:--------------------------|:-------------------|
| Type2_Diabetes      | Clinical            |      0.9996 |      0.9996 |         0      |     0.9994 |     0.9994 |        0      | 0.9963 | 0.9963 |    0      |    0.0075 |    0.0075 |       0      | [0.0000, 0.0000]          | False              |
| Prediabetes         | Clinical            |      0.9993 |      0.9993 |         0      |     0.9985 |     0.9985 |        0      | 0.9913 | 0.9913 |    0      |    0.0057 |    0.0057 |       0      | [0.0000, 0.0000]          | False              |
| High_Adiposity_Risk | Clinical            |      0.9665 |      0.9686 |         0.0022 |     0.9327 |     0.9353 |        0.0027 | 0.8424 | 0.8488 |    0.0064 |    0.0749 |    0.0745 |      -0.0003 | [0.0006, 0.0037]          | True               |
| Metabolic_Syndrome  | Clinical            |      0.9089 |      0.9205 |         0.0117 |     0.4665 |     0.5506 |        0.0841 | 0.414  | 0.4307 |    0.0167 |    0.1257 |    0.121  |      -0.0048 | [0.0054, 0.0177]          | True               |
| NAFLD               | Clinical            |      0.9109 |      0.9278 |         0.0169 |     0.6534 |     0.7121 |        0.0587 | 0.559  | 0.6088 |    0.0498 |    0.1226 |    0.1144 |      -0.0082 | [0.0106, 0.0232]          | True               |

- **Strategy B (equal-weight average)** underperforms Strategy A for every label except a marginal case on Metabolic_Syndrome ROC-AUC — confirming naive equal-weighting is not competitive and should not be used.
- **Strategy D (Logistic Regression stacking)** was **not fit in this phase.** Fitting it correctly requires 5-fold out-of-fold (OOF) predictions generated from Train, and no Train predictions were exported in the artifact-inventory task (confirmed absent in Section 1 / artifact report). Attempting to fit a stacker on any other data available in this phase (e.g., in-sample Train predictions, if they existed, or Validation itself) would violate the leakage rule this project has treated as non-negotiable throughout. Strategy D remains a valid future candidate, gated on a separate OOF-generation task.
- **Strategy E (nonlinear meta-learner)** remains conceptual only, per spec, and there is no evidence in this phase that linear methods are insufficient — the grid-search weighted average already captures most of the achievable gain with 3 free parameters, and the effect sizes involved (see Section 8) do not obviously require nonlinear capacity.

**Every optimizer run assigned Wearable a weight of exactly 0** across all 5 diseases. This was not a close call requiring a tie-breaking rule — the grid search explored the full weight simplex at 0.1 resolution and consistently found configurations with 0% Wearable weight strictly dominant. Combined with the correlation findings (Section 3), the most defensible reading is that Wearable's CGM-driven signal is functionally redundant with Clinical wherever Clinical is strong, and too weak standalone wherever Clinical is not.

---

## Section 8 — Disease-by-Disease Fusion Potential

| Disease             | Best Modality   |   Clinical AUC |   Wearable AUC |   Gut AUC |   Cl-We r |   Cl-Gu r |   We-Gu r | Fusion Potential     |
|:--------------------|:----------------|---------------:|---------------:|----------:|----------:|----------:|----------:|:---------------------|
| Type2_Diabetes      | Clinical        |         0.9996 |         0.9909 |    0.8236 |      0.92 |      0.54 |      0.54 | NONE / NOT JUSTIFIED |
| Prediabetes         | Clinical        |         0.9993 |         0.9648 |    0.617  |      0.84 |      0.18 |      0.18 | NONE / NOT JUSTIFIED |
| High_Adiposity_Risk | Clinical        |         0.9665 |         0.7959 |    0.8061 |      0.61 |      0.5  |      0.44 | MODERATE             |
| Metabolic_Syndrome  | Clinical        |         0.9089 |         0.7387 |    0.8359 |      0.46 |      0.49 |      0.49 | HIGH                 |
| NAFLD               | Clinical        |         0.9109 |         0.5914 |    0.815  |      0.23 |      0.37 |      0.51 | HIGH                 |

**Detailed reasoning per disease:**

**Type2_Diabetes — NONE / NOT JUSTIFIED.** Clinical Val ROC-AUC 0.9996. Optimizer assigns 100% weight to Clinical; bootstrap CI on any improvement is exactly [0, 0] because the optimal blend *is* pure Clinical. Clinical-Wearable correlation (0.92) confirms redundancy. Clinical is wrong on only 8 of 3,000 Validation patients — too few for any rescue claim to be statistically meaningful even if one existed.

**Prediabetes — NONE / NOT JUSTIFIED.** Same structural pattern as T2D. Clinical Val ROC-AUC 0.9993, optimizer selects pure Clinical, CI = [0, 0]. Gut is nearly uncorrelated with Clinical (r=0.18) but is also close to noise standalone (AUC 0.617) and does not rescue above its own baseline accuracy when Clinical is wrong (17 cases).

**High_Adiposity_Risk — MODERATE.** Real, bootstrap-confirmed improvement (ROC-AUC +0.0022, 95% CI [0.0006, 0.0037], excludes zero) from an 80/0/20 Clinical/Wearable/Gut blend. PR-AUC and F1 both improve modestly. Confidence-band analysis shows a real but smaller version of the Metabolic_Syndrome/NAFLD pattern — Clinical dips to ~0.51–0.54 accuracy in its own 0.4–0.8 band, where Gut holds ~0.60–0.68. Worth pursuing in Phase 2, with realistic expectations of a modest effect size.

**Metabolic_Syndrome — HIGH.** The strongest ROC-AUC evidence (+0.0117, CI [0.0054, 0.0177]) combined with the largest relative PR-AUC gain (+0.084 absolute, from 0.467 to 0.551 — substantial for a 7.7%-prevalence label where PR-AUC is the more diagnostic metric than ROC-AUC). The confidence-band mechanism (Section 6) gives this a causal story, not just a favorable point estimate: Clinical's accuracy genuinely collapses in its own uncertain region, and Gut holds up there. Gut receives 30% optimizer weight, Wearable 0%.

**NAFLD — HIGH.** The largest absolute ROC-AUC gain in the dataset (+0.0169, CI [0.0106, 0.0232]), the largest F1 gain (+0.0498), and a large PR-AUC gain (+0.0587). Same confidence-band mechanism as Metabolic_Syndrome, even more pronounced (Clinical accuracy 0.288 vs Gut 0.655 in the 0.6–0.8 band). Gut receives 40% optimizer weight — the highest of any label — and Wearable again receives 0%.

---

## Section 9 — Missing-Modality Status

- **Modality-level missingness is NOT represented in the current dataset.** All 20,000 patients (Train + Val + Test) have complete Clinical, Wearable, and Gut data. This was verified directly against the underlying feature datasets, not assumed.
- Feature-level missingness exists only within Gut (1,922 MCAR rows), already resolved via Train-only median imputation prior to model training — this is a different phenomenon and does not inform modality-level missing-data behavior.
- **Consequence**: any missing-modality Fusion strategy (single-modality passthrough, two-modality fallback, mask-aware architecture) remains an **open design question with zero empirical support from the current data.** It cannot be validated, tuned, or chosen with evidence until either (a) synthetic modality-dropout is deliberately constructed and validated as a stated assumption, or (b) real deployment missingness patterns become available. This matches the posture from prior architecture discussion in this project and is not resolved by this report.
- No coefficient-to-weight conversion, mask-imputation scheme, or pairwise fallback model was fit or proposed in this phase, per the hard restriction in the spec.

---

## Section 10 — Architecture Recommendation (Provisional Only)

This is **not a frozen architecture**. It is the recommendation the evidence in this report currently supports, pending the caveats below.

```
Type2_Diabetes       → Clinical passthrough (no fusion)
Prediabetes          → Clinical passthrough (no fusion)
High_Adiposity_Risk  → Fusion candidate (Clinical + Gut blend); modest effect, worth pursuing
Metabolic_Syndrome   → Fusion candidate (Clinical + Gut blend); strong effect, high priority
NAFLD                → Fusion candidate (Clinical + Gut blend); strongest effect, high priority
```

Wearable is not incrementally useful to Fusion for any of the five labels in the current evidence. This does not mean Wearable's own standalone model should be discarded — it remains independently deployable — but it should not be included as a Fusion input pending contrary evidence.

Logistic Regression stacking (Strategy D/E from the original architecture discussion) remains the most likely production architecture for the labels marked Fusion candidate above, but **has not been fit or validated in this phase** and requires a separate OOF-generation task before it can be evaluated on equal footing with the weighted-average results reported here.

---

## Required Answers (Section 15 of the Phase 1 spec)

1. **Does Fusion provide meaningful incremental information for Type2_Diabetes?** No. Optimizer selects pure Clinical; CI on improvement is exactly zero.
2. **Prediabetes?** No. Same pattern as T2D.
3. **High_Adiposity_Risk?** Yes, modestly. Bootstrap CI excludes zero but the effect is small (+0.0022 ROC-AUC).
4. **Metabolic_Syndrome?** Yes, substantially. Large PR-AUC gain with a mechanistic explanation (confidence-band collapse).
5. **NAFLD?** Yes, the most substantially of any label. Largest ROC-AUC, F1, and PR-AUC gains, same mechanistic explanation.
6. **Which diseases should remain single-modality?** Type2_Diabetes, Prediabetes.
7. **Which diseases should use Fusion?** High_Adiposity_Risk (moderate priority), Metabolic_Syndrome and NAFLD (high priority).
8. **Is Logistic Regression stacking actually justified?** Not yet evaluated — requires OOF Train predictions not available in this phase. The weighted-average results suggest a linear combination (which LR stacking is) is a reasonable functional form, since a 3-parameter weighted blend already captures most of the achievable gain.
9. **Is equal/weighted averaging competitive enough that stacking is unnecessary?** Possibly, for the weighted-average case specifically — but this cannot be confirmed until stacking is actually fit on leakage-free OOF data and compared head-to-head under the same Val evaluation.
10. **Are modality errors sufficiently complementary?** Only in a specific, identifiable region (Clinical's own 0.4–0.8 confidence band) for Metabolic_Syndrome, NAFLD, and to a lesser extent High_Adiposity_Risk. Not complementary in the aggregate, pairwise correct/wrong sense — see Section 5's uniformly negative rescue deltas.
11. **What should happen when only one modality is available?** Unresolved — no missing-modality data exists to validate any approach. Current best posture (per earlier architecture discussion): raw single-modality probability passthrough, pending evidence.
12. **What should happen when exactly two modalities are available?** Unresolved for the same reason.
13. **Is the missing-modality problem represented in the current data?** No — confirmed directly from the underlying feature data, not assumed.
14. **What information is still required before freezing the Fusion Architecture Decision Document?** (a) OOF Train predictions to properly fit and evaluate LR stacking; (b) a leakage-free re-confirmation of the weighted-average effect sizes (the current Strategy C numbers are optimistic because weights were tuned and evaluated on the same Validation set); (c) any real or deliberately-constructed missing-modality data to inform Section 9's open question; (d) a single final Test-set evaluation, performed once, after all of the above.
15. **What must NOT be done because it would introduce leakage?** Fitting any meta-learner (LR stacking or otherwise) on in-sample Train predictions from the already-fitted base models; using Test for any weight, threshold, or architecture decision; treating the current Strategy C weighted-average numbers as a final, unbiased performance estimate rather than an optimistic upper bound requiring re-confirmation.

---

## Appendix — Files Produced This Session

- `calibration_metrics.csv` — full per-disease/modality calibration table
- `correlation_pearson.csv`, `correlation_spearman.csv`
- `disagreement_tables.json`
- `base_classification_metrics.csv`, `error_overlap.csv`, `rescue_analysis.csv`
- `confidence_band_analysis.csv`
- `strategy_comparison.csv`, `strategy_full_comparison.csv`
- `fusion_potential_table.csv`
- `plots/reliability_diagrams.png`, `plots/correlation_heatmaps.png`

All computed from `fusion_val_master.csv` (Validation, n=3,000) unless noted as Test/descriptive. Test set was not used for any decision in this report.
